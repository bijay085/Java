// question number 5, body mass index

import java.util.*;
class bmi {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter your weight in pounds:");
        double weight = in.nextDouble();
        System.out.println("Enter your height in inches:");
        double height = in.nextDouble();

        double bmi = (703*((weight)/(height*height)));
        System.out.println("The bmi is :" +bmi);
        
    }   
}