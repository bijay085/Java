/* Write a Java program that takes the user to provide a single character from the alphabet.
Print Vowel of Consonant, depending on the user input. If the user input is not a letter
(between a and z or A and Z), or is a string of length > 1, print an error message.*/
//question number 4


import java.util.Scanner;
class Vowel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a single character: ");
        String input = scanner.nextLine();

        if (input.length() == 1 && Character.isLetter(input.charAt(0))) {
            char character = input.charAt(0);
            if (character == 'A' || character == 'E' || character == 'I' || character == 'O' || character == 'U' ||
                    character == 'a' || character == 'e' || character == 'i' || character == 'o' || character == 'u') {
                System.out.println("Vowel");
            } else {
                System.out.println("Consonant");
            }
        } else {
            System.out.println("Error: Please enter a single letter.");
        }
    }
}
