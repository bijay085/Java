//question number 12

import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char choice;

        System.out.println("Menu:");
        System.out.println("c. Circle");
        System.out.println("s. Square");
        System.out.println("r. Rectangle");
        System.out.println("t. Triangle");
        System.out.println("e. Exit");

        System.out.print("Enter your choice: ");
        choice = scanner.next().charAt(0);

        double area = 0;

        switch (choice) {
            case 'c':
                System.out.print("Enter the radius of the circle: ");
                double radius = scanner.nextDouble();
                area = Math.PI * radius * radius;
                System.out.println("The area of the circle is: " + area);
                break;
            case 's':
                System.out.print("Enter the side length of the square: ");
                double sideLength = scanner.nextDouble();
                area = sideLength * sideLength;
                System.out.println("The area of the square is: " + area);
                break;
            case 'r':
                System.out.print("Enter the length of the rectangle: ");
                double length = scanner.nextDouble();
                System.out.print("Enter the width of the rectangle: ");
                double width = scanner.nextDouble();
                area = length * width;
                System.out.println("The area of the rectangle is: " + area);
                break;
            case 't':
                System.out.print("Enter the base length of the triangle: ");
                double baseLength = scanner.nextDouble();
                System.out.print("Enter the height of the triangle: ");
                double height = scanner.nextDouble();
                area = 0.5 * baseLength * height;
                System.out.println("The area of the triangle is: " + area);
                break;
            case 'e':
                System.out.println("Exiting the program.");
                break;
            default:
                System.out.println("Invalid choice. Please select a valid option.");
        }
    }
}
