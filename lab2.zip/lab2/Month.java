import java.util.Scanner;

public class Month {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the month (1-12): ");
        int month = scanner.nextInt();

        int days = 0;

        if (month >= 1 && month <= 12) {
            if (month == 2) {
                System.out.print("Enter the year: ");
                int year = scanner.nextInt();
                days = (isLeapYear(year)) ? 29 : 28;
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                days = 30;
            } else {
                days = 31;
            }

            System.out.println("Number of days in the month: " + days);
        } else {
            System.out.println("Invalid month");
        }
    }

    // Method to check if a year is a leap year
    public static boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }
}
