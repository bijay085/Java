//question number 11

import java.util.Scanner;

public class AOP {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double number1 = scanner.nextDouble();

        System.out.print("Enter the second number: ");
        double number2 = scanner.nextDouble();

        System.out.println("Select an operation:");
        System.out.println("1. Addition (+)");
        System.out.println("2. Subtraction (-)");
        System.out.println("3. Multiplication (*)");
        System.out.println("4. Division (/)");
        System.out.println("5. Exit.");

        System.out.print("Enter your choice (1-4): ");
        int choice = scanner.nextInt();

        double result = 0;

        switch (choice) {
            case 1:
                result = number1 + number2;
                System.out.println("Result: " + number1 + " + " + number2 + " = " + result);
                break;
            case 2:
                result = number1 - number2;
                System.out.println("Result: " + number1 + " - " + number2 + " = " + result);
                break;
            case 3:
                result = number1 * number2;
                System.out.println("Result: " + number1 + " * " + number2 + " = " + result);
                break;
            case 4:
                if (number2 == 0) {
                    System.out.println("Error: Division by zero is not allowed.");
                } else {
                    result = number1 / number2;
                    System.out.println("Result: " + number1 + " / " + number2 + " = " + result);
                }
                break;
            case 5:
                 System.out.println("Exiting The system.");
            default:
                System.out.println("Invalid choice. Please select a valid operation.");
        }
    }
}
